Facebook Marketplace — Ambulance listing pack
=============================================

5 diesel ambulances, $1,500 each, not running.
Local pickup: Blythewood, SC (200 Louthian Way).

How to post on Facebook Marketplace
-----------------------------------
1. Unzip this file.
2. Open one truck folder (01 … 05).
3. Upload every photo from the photos/ folder.
4. Copy title from title.txt
5. Copy the full description from description.txt
   (or use facebook-post.txt which has title + description together)
6. Set price to $1500, condition Used, category Vehicles / Other.
7. Repeat for each truck.

Folders
-------
01-2008-ford-e350-truck-1  — 365k, new transmission
02-2008-ford-e350-truck-2  — 176k, injectors replaced
03-2010-ford-e350-truck-3  — 355k
04-2009-ford-e350-truck-4  — 346k, refurbished AC
05-2010-ford-e350-truck-5  — 377k

Also included: listings-summary.csv (quick overview)
